import React from "react";
import { Link } from "react-router-dom";
import {
  FaFacebook,
  FaTwitter,
  FaYoutube,
  FaTelegram,
  FaMapMarkerAlt,
  FaPhoneAlt,
  FaEnvelope
} from "react-icons/fa";

export default function Footer() {
  return <footer className="w-full font-robotoSlab">
      <div className="w-full bg-green-800 text-white font-montserrat px-2 lg:pt-20 py-5">
        <div className="max-w-7xl mx-auto">
          <div className="grid lg:grid-cols-4 lg:gap-5 gap-8">
            <div className="pr-3">
              <h2 className="text-2xl">About Us</h2>
              <p className="text-sm">
                25th years ago Phaung Daw Oo monastic education school was
                established by the two brothers, Ven Nayaka and Ven Jotika.
              </p>
              <div className="flex flex-row gap-5 text-2xl mt-5">
                <a href="#" aria-label="Facebook" className="text-yellow-300 hover:text-white transition-colors">
                  <FaFacebook />
                </a>
                <a href="#" aria-label="Twitter" className="text-yellow-300 hover:text-white transition-colors">
                  <FaTwitter />
                </a>
                <a href="#" aria-label="YouTube" className="text-yellow-300 hover:text-white transition-colors">
                  <FaYoutube />
                </a>
                <a href="#" aria-label="Telegram" className="text-yellow-300 hover:text-white transition-colors">
                  <FaTelegram />
                </a>
              </div>
            </div>
            <div>
              <h2 className="text-2xl">Useful Links</h2>
              <ul className="text-sm">
                <li className="list-item">
                  <Link to="/">Home</Link>
                </li>
                <li className="list-item">
                  <Link to="/about-us">About Us</Link>
                </li>
                <li className="list-item">
                  <Link to="/courses">Courses</Link>
                </li>
                <li className="list-item">
                  <Link to="/campus">Campus</Link>
                </li>
                <li className="list-item">
                  <Link to="/faculties">Faculties</Link>
                </li>
              </ul>
            </div>
            <div>
              <h2 className="text-2xl">Popular Courses</h2>
              <ul className="text-sm">
                <li className="list-item">
                  <Link to="/courses/master-of-arts-in-social-entrepreneurship">
                    Social Entrepreneurship
                  </Link>
                </li>
                <li className="list-item">
                  <Link to="/courses/bachelor-of-arts-in-business-management">
                    Business Administration
                  </Link>
                </li>
                <li className="list-item">
                  <Link to="/courses/bachelor-of-science-in-information-technology">
                    Information Technology
                  </Link>
                </li>
                <li className="list-item">
                  <Link to="/courses/bachelor-of-arts-in-social-sciences">
                    Social Science
                  </Link>
                </li>
              </ul>
            </div>
            <div>
              <h2 className="text-2xl">Contact Info</h2>
              <div className="grid grid-rows gap-1">
                <div className="flex flex-row items">
                  <div>
                    <FaMapMarkerAlt className="text-3xl text-green-900 bg-yellow-400 rounded-full p-2" />
                  </div>
                  <div className="px-3 w-full font-regular">
                    <strong>Address</strong>
                    <br />
                    <p className="text-sm">
                      Dawnabwar Block, Nanshae Aungmyaetharzan Tsp, Mandalay,
                      Myanmar
                    </p>
                  </div>
                </div>
                <div className="flex flex-row items">
                  <div>
                    <FaPhoneAlt className="text-3xl text-green-900 bg-yellow-400 rounded-full p-2" />
                  </div>
                  <div className="flex flex-col px-3 w-full font-regular">
                    <strong>Phone</strong>
                    <a href="tel:+959767119812">
                      <p className="text-sm">+959 767 1198 12</p>
                    </a>
                  </div>
                </div>
                <div className="flex flex-row items">
                  <div>
                    <FaEnvelope className="text-3xl text-green-900 bg-yellow-400 rounded-full p-2" />
                  </div>
                  <div className="flex flex-col px-3 w-full font-regular">
                    <strong>Email</strong>
                    <a href="mailto:piu.edu2014@gmail.com">
                      <p className="text-sm">piu.edu2014@gmail.com</p>
                    </a>
                  </div>
                </div>
              </div>
            </div>
          </div>
          <div className="mt-5 pt-3 border-t border-green-600 lg:flex flex-row justify-between items-center text-sm text-center">
            <div>
              <p>
                Copyright &copy; {new Date().getFullYear()}, All Rights Reserved
              </p>
            </div>
            <div>
              <Link to="#!">Developed by PIU-Webdeveloper Team</Link>
            </div>
          </div>
        </div>
      </div>
    </footer>;
}
