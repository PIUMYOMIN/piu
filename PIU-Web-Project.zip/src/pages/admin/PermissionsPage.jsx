import React, { useState, useEffect } from "react";
import { FaEdit, FaTrash, FaPlus, FaSpinner } from "react-icons/fa";
import { adminApi } from "../../api/admin";
import { useAuth } from "../../contexts/AuthContext";
import { useFloatingToast } from "../../hooks/useFloatingToast";
import { getApiErrorMessage } from "../../utils/apiErrors";
import ManagementFilters from "../../components/admin/ManagementFilters";

function PermissionsPage() {
  const { user: authUser } = useAuth();
  const { showSuccess, showError, Toast } = useFloatingToast();
  const currentRole = String(
    authUser?.role?.name ??
      authUser?.role ??
      (Array.isArray(authUser?.roles) ? authUser.roles[0]?.name || authUser.roles[0] : "")
  ).toLowerCase();
  const isAdmin = currentRole === "admin";
  const [permissions, setPermissions] = useState([]);
  const [roles, setRoles] = useState([]);
  const [loading, setLoading] = useState(true);
  const [editingPerm, setEditingPerm] = useState(null);
  const [assignedRoleIds, setAssignedRoleIds] = useState([]);
  const [permissionName, setPermissionName] = useState("");
  const [isAddModalOpen, setIsAddModalOpen] = useState(false);
  const [newPermissionName, setNewPermissionName] = useState("");
  const [search, setSearch] = useState("");
  const [roleFilter, setRoleFilter] = useState("all");
  const [currentPage, setCurrentPage] = useState(1);
  const pageSize = 10;

  // Fetch data
  useEffect(() => {
    fetchData();
  }, []);

  const fetchData = async () => {
    try {
      setLoading(true);
      const [permissionsData, rolesData] = await Promise.all([
        adminApi.permissions.list(),
        adminApi.roles.list(),
      ]);

      setPermissions(Array.isArray(permissionsData) ? permissionsData : []);
      setRoles(Array.isArray(rolesData) ? rolesData : []);
    } catch (error) {
      console.error("Error fetching data:", error);
      showError(getApiErrorMessage(error, "Failed to fetch data"));
    } finally {
      setLoading(false);
    }
  };

  const openEdit = (perm) => {
    // Find roles that have this permission
    const assignedRoles = roles.filter(role => 
      role.permissions?.some(p => p.id === perm.id || p === perm.id)
    ).map(role => role.id);
    
    setEditingPerm(perm);
    setPermissionName(perm.name);
    setAssignedRoleIds(assignedRoles);
  };

  const closeModal = () => {
    setEditingPerm(null);
    setPermissionName("");
    setAssignedRoleIds([]);
  };

  const toggleRoleAssignment = (roleId) => {
    setAssignedRoleIds(prev =>
      prev.includes(roleId) 
        ? prev.filter(id => id !== roleId) 
        : [...prev, roleId]
    );
  };

  const saveChanges = async () => {
    if (!editingPerm || !permissionName.trim()) {
      showError("Permission name is required");
      return;
    }

    try {
      // Update permission name
      if (editingPerm.name !== permissionName) {
        await adminApi.permissions.update(editingPerm.id, {
          name: permissionName
        });
      }

      // Update role permissions
      await Promise.all(
        roles.map(async (role) => {
          const shouldHave = assignedRoleIds.includes(role.id);
          const currentlyHas = role.permissions?.some(p => 
            p.id === editingPerm.id || p === editingPerm.id
          );

          if (shouldHave !== currentlyHas) {
            const currentPerms = role.permissions?.map(p => p.id || p) || [];
            const newPerms = shouldHave
              ? [...currentPerms, editingPerm.id]
              : currentPerms.filter(id => id !== editingPerm.id);

            await adminApi.roles.update(role.id, {
              name: role.name,
              permissions: newPerms
            });
          }
        })
      );

      // Refresh data
      await fetchData();
      closeModal();
      showSuccess("Permission updated successfully");
    } catch (error) {
      console.error("Error updating permission:", error);
      showError(getApiErrorMessage(error, "Failed to update permission"));
    }
  };

  const handleAddPermission = async () => {
    if (!newPermissionName.trim()) {
      showError("Permission name is required");
      return;
    }

    try {
      await adminApi.permissions.create({
        name: newPermissionName
      });
      
      await fetchData();
      setNewPermissionName("");
      setIsAddModalOpen(false);
      showSuccess("Permission added successfully");
    } catch (error) {
      console.error("Error adding permission:", error);
      showError(getApiErrorMessage(error, "Failed to add permission"));
    }
  };

  const handleDeletePermission = async (permissionId) => {
    if (!isAdmin) return;
    if (!window.confirm("Are you sure you want to delete this permission?")) {
      return;
    }

    try {
      await adminApi.permissions.remove(permissionId);
      setPermissions(permissions.filter(p => p.id !== permissionId));
      showSuccess("Permission deleted successfully");
    } catch (error) {
      console.error("Error deleting permission:", error);
      showError(getApiErrorMessage(error, "Failed to delete permission"));
    }
  };

  const filteredPermissions = permissions.filter((p) => {
    const matchesSearch = String(p?.name || "").toLowerCase().includes(search.trim().toLowerCase());
    if (roleFilter === "all") return matchesSearch;
    const assigned = roles.some(
      (role) =>
        String(role.id) === roleFilter &&
        role.permissions?.some((perm) => perm.id === p.id || perm === p.id)
    );
    return matchesSearch && assigned;
  });
  const totalPages = Math.max(1, Math.ceil(filteredPermissions.length / pageSize));
  const paginatedPermissions = filteredPermissions.slice((currentPage - 1) * pageSize, currentPage * pageSize);

  const resetFilters = () => {
    setSearch("");
    setRoleFilter("all");
    setCurrentPage(1);
  };

  const roleOptions = [
    { value: "all", label: "All Roles" },
    ...roles.map((role) => ({ value: String(role.id), label: role.name })),
  ];

  if (loading) {
    return (
      <div className="flex justify-center items-center h-64">
        <Toast />
        <FaSpinner className="animate-spin text-2xl text-blue-500" />
      </div>
    );
  }

  return (
    <div className="bg-white p-6 rounded shadow w-full">
      <Toast />
      
      <div className="flex justify-between items-center mb-6">
        <h2 className="text-xl font-bold text-gray-800">All Permissions</h2>
      </div>

      <ManagementFilters
        searchValue={search}
        onSearchChange={(value) => {
          setSearch(value);
          setCurrentPage(1);
        }}
        searchPlaceholder="Search permission..."
        filters={[
          {
            key: "role",
            value: roleFilter,
            onChange: (value) => {
              setRoleFilter(value);
              setCurrentPage(1);
            },
            options: roleOptions,
          },
        ]}
        onReset={resetFilters}
        actions={
          <button
            onClick={() => setIsAddModalOpen(true)}
            className="bg-blue-500 hover:bg-blue-600 text-white px-4 py-2 rounded flex items-center gap-2"
          >
            <FaPlus /> Add New Permission
          </button>
        }
      />

      <div className="overflow-x-auto">
        <table className="table-auto w-full border border-gray-200">
          <thead>
            <tr className="bg-gray-50">
              <th className="px-4 py-3 border border-gray-200 text-left text-sm font-semibold text-gray-600">#</th>
              <th className="px-4 py-3 border border-gray-200 text-left text-sm font-semibold text-gray-600">Name</th>
              <th className="px-4 py-3 border border-gray-200 text-left text-sm font-semibold text-gray-600">Assigned to Roles</th>
              <th className="px-4 py-3 border border-gray-200 text-left text-sm font-semibold text-gray-600">Actions</th>
            </tr>
          </thead>
          <tbody>
            {filteredPermissions.length === 0 ? (
              <tr>
                <td colSpan="4" className="px-4 py-8 text-center text-gray-500">
                  No permissions found
                </td>
              </tr>
            ) : (
              paginatedPermissions.map((perm, index) => {
                const assignedRoles = roles.filter(role => 
                  role.permissions?.some(p => p.id === perm.id || p === perm.id)
                ).map(role => role.name);

                return (
                  <tr key={perm.id} className="hover:bg-gray-50">
                    <td className="px-4 py-3 border border-gray-200">{(currentPage - 1) * pageSize + index + 1}</td>
                    <td className="px-4 py-3 border border-gray-200 font-medium">{perm.name}</td>
                    <td className="px-4 py-3 border border-gray-200">
                      <div className="flex flex-wrap gap-1">
                        {assignedRoles.length > 0 ? (
                          assignedRoles.map(roleName => (
                            <span 
                              key={roleName}
                              className="px-2 py-1 bg-green-100 text-green-800 text-xs rounded"
                            >
                              {roleName}
                            </span>
                          ))
                        ) : (
                          <span className="text-gray-400 text-sm">Not assigned to any role</span>
                        )}
                      </div>
                    </td>
                    <td className="px-4 py-3 border border-gray-200">
                      <div className="flex gap-3">
                        <button
                          className="inline-flex items-center gap-2 text-blue-600 hover:text-blue-800"
                          onClick={() => openEdit(perm)}
                        >
                          <FaEdit /> Edit
                        </button>
                        {isAdmin && (
                          <button
                            className="inline-flex items-center gap-2 text-red-600 hover:text-red-800"
                            onClick={() => handleDeletePermission(perm.id)}
                          >
                            <FaTrash /> Delete
                          </button>
                        )}
                      </div>
                    </td>
                  </tr>
                );
              })
            )}
          </tbody>
        </table>
      </div>

      {filteredPermissions.length > 0 && (
        <div className="mt-4 flex items-center justify-between text-sm">
          <div>
            Page {currentPage} of {totalPages}
          </div>
          <div className="flex gap-2">
            <button
              type="button"
              onClick={() => setCurrentPage((p) => Math.max(1, p - 1))}
              disabled={currentPage === 1}
              className="px-3 py-1 border rounded disabled:opacity-50"
            >
              Prev
            </button>
            <button
              type="button"
              onClick={() => setCurrentPage((p) => Math.min(totalPages, p + 1))}
              disabled={currentPage === totalPages}
              className="px-3 py-1 border rounded disabled:opacity-50"
            >
              Next
            </button>
          </div>
        </div>
      )}

      {/* Edit Permission Modal */}
      {editingPerm && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black bg-opacity-50">
          <div className="bg-white rounded-lg w-full max-w-lg p-6">
            <h3 className="text-lg font-semibold mb-4">Edit Permission</h3>

            <div className="mb-4">
              <label className="block text-sm font-medium mb-2">Permission Name</label>
              <input
                type="text"
                value={permissionName}
                onChange={(e) => setPermissionName(e.target.value)}
                className="w-full border border-gray-300 rounded px-3 py-2 focus:outline-none focus:ring-2 focus:ring-blue-500"
              />
            </div>

            <div className="mb-6">
              <h4 className="font-semibold mb-2">Assign to Roles</h4>
              <div className="border border-gray-300 rounded p-3 max-h-48 overflow-y-auto">
                <div className="grid grid-cols-2 gap-2">
                  {roles.map((role) => (
                    <label key={role.id} className="flex items-center gap-2">
                      <input
                        type="checkbox"
                        checked={assignedRoleIds.includes(role.id)}
                        onChange={() => toggleRoleAssignment(role.id)}
                        className="rounded"
                      />
                      <span className="text-sm">{role.name}</span>
                    </label>
                  ))}
                </div>
              </div>
            </div>

            <div className="flex justify-end gap-3">
              <button
                onClick={closeModal}
                className="px-4 py-2 border border-gray-300 rounded hover:bg-gray-50"
              >
                Cancel
              </button>
              <button
                onClick={saveChanges}
                className="px-4 py-2 bg-blue-500 text-white rounded hover:bg-blue-600"
              >
                Save Changes
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Add Permission Modal */}
      {isAddModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black bg-opacity-50">
          <div className="bg-white rounded-lg w-full max-w-md p-6">
            <h3 className="text-lg font-semibold mb-4">Add New Permission</h3>
            
            <div className="mb-6">
              <label className="block text-sm font-medium mb-2">Permission Name</label>
              <input
                type="text"
                value={newPermissionName}
                onChange={(e) => setNewPermissionName(e.target.value)}
                className="w-full border border-gray-300 rounded px-3 py-2 focus:outline-none focus:ring-2 focus:ring-blue-500"
                placeholder="Enter permission name (e.g., users.create)"
              />
              <p className="text-xs text-gray-500 mt-1">
                Use dot notation: resource.action (e.g., users.create, roles.view)
              </p>
            </div>

            <div className="flex justify-end gap-3">
              <button
                onClick={() => {
                  setIsAddModalOpen(false);
                  setNewPermissionName("");
                }}
                className="px-4 py-2 border border-gray-300 rounded hover:bg-gray-50"
              >
                Cancel
              </button>
              <button
                onClick={handleAddPermission}
                className="px-4 py-2 bg-blue-500 text-white rounded hover:bg-blue-600"
              >
                Add Permission
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}

export default PermissionsPage;